from django.shortcuts import render
from .models import Bicicleta
from .models import Neumatico
from .models import Freno

# Create your views here.

def bicicleta(request):
    bicicletas = Bicicleta.objects.all()
    return render(request, 'paginapp/bicicleta.html', {'bicicletas': bicicletas})

def neumatico(request):
    neumaticos = Neumatico.objects.all()
    return render(request, 'paginapp/neumatico.html', {'neumaticos' : neumaticos})

def frenos(request):
    frenos = Freno.objects.all()
    return render(request, 'paginapp/frenos.html', {'frenos': frenos})

