from cgitb import html
from django.shortcuts import render, HttpResponse

# Create your views here.


def index(request):
    return render(request, 'pagina/index.html') 


def tecnico(request):
    return render(request, 'pagina/tecnico.html')

def login(request):
    return render(request, 'pagina/login.html')

def recuperar_contraseña(request):
    return render(request, 'pagina/recupera_contra.html')

def registrar(request):
    return render(request, 'pagina/registrar.html')